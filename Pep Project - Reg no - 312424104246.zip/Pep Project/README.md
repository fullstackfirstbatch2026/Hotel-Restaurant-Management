# Grand Azure Hotel & Restaurant Management System 🏨🍽️

A Full-Stack Hotel & Restaurant Management System built with **Spring Boot 3**, **Hibernate / JPA**, **H2 DBMS**, **Docker**, and a **Modern UI Dashboard**.

---

## 🎯 Requirements Coverage

| Requirement | Implementation & Location |
| :--- | :--- |
| **Database Tables** | `GUESTS`, `MENU_ITEMS`, `RESTAURANT_ORDERS`, `ORDER_ITEMS`, `ORDER_AUDIT_LOG` defined in [`schema.sql`](src/main/resources/schema.sql) and mapped via JPA entities in `com.hotel.restaurant.model.*`. |
| **JOIN Query** | 4-table SQL JOIN combining orders, guests, order line items, and menu catalog in [`OrderRepository.java`](src/main/java/com/hotel/restaurant/repository/OrderRepository.java) (`GET /api/orders/detailed`). |
| **Subquery** | Computes menu items whose total ordered quantity is above average in [`MenuItemRepository.java`](src/main/java/com/hotel/restaurant/repository/MenuItemRepository.java) (`GET /api/menu/above-average`). |
| **Stored Procedure** | `CREATE_RESTAURANT_ORDER`: Creates order header, inserts item lines, and computes total amount in [`H2DatabaseRoutines.java`](src/main/java/com/hotel/restaurant/routine/H2DatabaseRoutines.java) (`POST /api/orders/procedure/create`). |
| **Stored Function** | `CALCULATE_ORDER_BILL`: Computes itemized bill with 5% GST, 5% Service Charge, and 10% Hotel Guest discount in [`H2DatabaseRoutines.java`](src/main/java/com/hotel/restaurant/routine/H2DatabaseRoutines.java) (`GET /api/orders/{id}/calculate-bill`). |
| **Database Trigger** | `TRG_UPDATE_ORDER_STATUS`: Automatically records transition audit entries in `ORDER_AUDIT_LOG` in [`OrderStatusTrigger.java`](src/main/java/com/hotel/restaurant/routine/OrderStatusTrigger.java) (`PATCH /api/orders/{id}/status`). |
| **Frontend UI** | Stylish glassmorphism login with animated ambient background (`/login.html`) and responsive single-page management dashboard (`/index.html`). |

---

## 🐙 Step 1: Push Project to GitHub

Open your terminal inside the project root (`C:\Users\tarun\Pep2\Pep Project`) and run:

```powershell
# 1. Initialize Git Repository
git init

# 2. Add all project files
git add .

# 3. Create initial commit
git commit -m "Initial commit: Hotel Restaurant Management Spring Boot + H2 Full Stack Project"

# 4. Set main branch
git branch -M main

# 5. Link to your GitHub remote repository (replace with your repo URL)
git remote add origin https://github.com/YOUR_GITHUB_USERNAME/hotel-restaurant-management.git

# 6. Push code to GitHub
git push -u origin main
```

---

## 🐳 Step 2: Build & Run with Docker

### Option A: Using Docker Compose (Recommended)
```powershell
# Build image and start container in the background
docker compose up --build -d

# View running container status
docker compose ps

# View live application logs
docker compose logs -f

# Stop and remove container
docker compose down
```

### Option B: Using Plain Docker CLI
```powershell
# 1. Build the Docker Image
docker build -t hotel-restaurant-management:1.0.0 .

# 2. Run the Docker Container on port 8085
docker run -d -p 8085:8085 --name hotel_app hotel-restaurant-management:1.0.0

# 3. View container logs
docker logs -f hotel_app

# 4. Stop the container
docker stop hotel_app
```

---

## 🌐 Web Endpoints (Local & Docker)

* 🌟 **Staff Login Portal**: [http://localhost:8085/login.html](http://localhost:8085/login.html)
* 🖥️ **Management Dashboard**: [http://localhost:8085/](http://localhost:8085/)
* ⚡ **H2 Database Web Console**: [http://localhost:8085/h2-console](http://localhost:8085/h2-console)
  * **JDBC URL**: `jdbc:h2:mem:hoteldb`
  * **User Name**: `sa`
  * **Password**: *(leave blank)*
