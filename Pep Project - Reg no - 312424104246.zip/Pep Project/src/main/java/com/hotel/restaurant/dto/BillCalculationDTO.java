package com.hotel.restaurant.dto;

import java.math.BigDecimal;

public class BillCalculationDTO {
    private Long orderId;
    private String orderType;
    private String guestName;
    private String roomNumber;
    private String guestStatus;
    private BigDecimal subtotal;
    private BigDecimal taxAmount; // 5% GST
    private BigDecimal serviceChargeAmount; // 5% Service charge
    private BigDecimal discountAmount; // 10% Hotel Guest discount
    private BigDecimal finalPayableAmount; // Result from CALCULATE_ORDER_BILL

    public BillCalculationDTO() {
    }

    public BillCalculationDTO(Long orderId, String orderType, String guestName, String roomNumber,
                              String guestStatus, BigDecimal subtotal, BigDecimal taxAmount,
                              BigDecimal serviceChargeAmount, BigDecimal discountAmount, BigDecimal finalPayableAmount) {
        this.orderId = orderId;
        this.orderType = orderType;
        this.guestName = guestName;
        this.roomNumber = roomNumber;
        this.guestStatus = guestStatus;
        this.subtotal = subtotal;
        this.taxAmount = taxAmount;
        this.serviceChargeAmount = serviceChargeAmount;
        this.discountAmount = discountAmount;
        this.finalPayableAmount = finalPayableAmount;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getGuestName() {
        return guestName;
    }

    public void setGuestName(String guestName) {
        this.guestName = guestName;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getGuestStatus() {
        return guestStatus;
    }

    public void setGuestStatus(String guestStatus) {
        this.guestStatus = guestStatus;
    }

    public BigDecimal getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(BigDecimal subtotal) {
        this.subtotal = subtotal;
    }

    public BigDecimal getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(BigDecimal taxAmount) {
        this.taxAmount = taxAmount;
    }

    public BigDecimal getServiceChargeAmount() {
        return serviceChargeAmount;
    }

    public void setServiceChargeAmount(BigDecimal serviceChargeAmount) {
        this.serviceChargeAmount = serviceChargeAmount;
    }

    public BigDecimal getDiscountAmount() {
        return discountAmount;
    }

    public void setDiscountAmount(BigDecimal discountAmount) {
        this.discountAmount = discountAmount;
    }

    public BigDecimal getFinalPayableAmount() {
        return finalPayableAmount;
    }

    public void setFinalPayableAmount(BigDecimal finalPayableAmount) {
        this.finalPayableAmount = finalPayableAmount;
    }
}
