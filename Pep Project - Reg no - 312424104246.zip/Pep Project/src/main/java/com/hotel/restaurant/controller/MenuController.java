package com.hotel.restaurant.controller;

import com.hotel.restaurant.dto.AboveAverageItemDTO;
import com.hotel.restaurant.model.MenuItem;
import com.hotel.restaurant.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/menu")
@CrossOrigin(origins = "*")
public class MenuController {

    private final MenuService menuService;

    @Autowired
    public MenuController(MenuService menuService) {
        this.menuService = menuService;
    }

    @GetMapping
    public ResponseEntity<List<MenuItem>> getAllMenuItems() {
        return ResponseEntity.ok(menuService.getAllMenuItems());
    }

    @GetMapping("/available")
    public ResponseEntity<List<MenuItem>> getAvailableMenuItems() {
        return ResponseEntity.ok(menuService.getAvailableMenuItems());
    }

    @GetMapping("/{id}")
    public ResponseEntity<MenuItem> getMenuItemById(@PathVariable Long id) {
        return menuService.getMenuItemById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<MenuItem> createMenuItem(@RequestBody MenuItem menuItem) {
        MenuItem saved = menuService.saveMenuItem(menuItem);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    /**
     * Requirement: Find menu items ordered above average using a subquery.
     */
    @GetMapping("/above-average")
    public ResponseEntity<List<AboveAverageItemDTO>> getMenuItemsOrderedAboveAverage() {
        List<AboveAverageItemDTO> items = menuService.getMenuItemsOrderedAboveAverage();
        return ResponseEntity.ok(items);
    }
}
