package com.hotel.restaurant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelRestaurantApplication {

    public static void main(String[] args) {
        SpringApplication.run(HotelRestaurantApplication.class, args);
        System.out.println("==================================================================");
        System.out.println("  Hotel & Restaurant Management System Started Successfully!     ");
        System.out.println("  Web UI:        http://localhost:8085/                          ");
        System.out.println("  Login Page:    http://localhost:8085/login.html                ");
        System.out.println("  H2 Console:    http://localhost:8085/h2-console                ");
        System.out.println("  JDBC URL:      jdbc:h2:mem:hoteldb (User: sa, Password: empty) ");
        System.out.println("==================================================================");
    }
}
