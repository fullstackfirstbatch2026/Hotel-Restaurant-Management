package com.hotel.restaurant.dto;

public class StatusUpdateRequest {
    private String status; // PENDING, PREPARING, DELIVERED, BILLED, CANCELLED

    public StatusUpdateRequest() {
    }

    public StatusUpdateRequest(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
