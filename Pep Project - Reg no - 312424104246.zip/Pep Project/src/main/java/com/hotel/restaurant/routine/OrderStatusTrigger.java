package com.hotel.restaurant.routine;

import org.h2.api.Trigger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * Database Trigger: TRG_UPDATE_ORDER_STATUS
 * Automatically fires when RESTAURANT_ORDERS status is updated,
 * logging the state transition and audit trail into ORDER_AUDIT_LOG table.
 */
public class OrderStatusTrigger implements Trigger {

    @Override
    public void init(Connection conn, String schemaName, String triggerName, String tableName, boolean before, int type) {
        // Trigger initialization
    }

    @Override
    public void fire(Connection conn, Object[] oldRow, Object[] newRow) throws SQLException {
        if (oldRow == null || newRow == null) {
            return;
        }

        Long orderId = (Long) newRow[0];
        String oldStatus = oldRow[5] != null ? oldRow[5].toString() : null;
        String newStatus = newRow[5] != null ? newRow[5].toString() : null;

        // Check if status has changed
        if (newStatus != null && !newStatus.equalsIgnoreCase(oldStatus)) {
            String note = "Order #" + orderId + " transitioned from " + oldStatus + " to " + newStatus;
            String sql = "INSERT INTO ORDER_AUDIT_LOG (order_id, old_status, new_status, changed_at, action_note) " +
                         "VALUES (?, ?, ?, CURRENT_TIMESTAMP, ?)";

            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setLong(1, orderId);
                ps.setString(2, oldStatus);
                ps.setString(3, newStatus);
                ps.setString(4, note);
                ps.executeUpdate();
            }
        }
    }

    @Override
    public void close() {
    }

    @Override
    public void remove() {
    }
}
