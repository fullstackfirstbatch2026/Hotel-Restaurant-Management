package com.hotel.restaurant.repository;

import com.hotel.restaurant.model.Guest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface GuestRepository extends JpaRepository<Guest, Long> {
    List<Guest> findByStatus(String status);
    Optional<Guest> findByRoomNumberAndStatus(String roomNumber, String status);
    long countByStatus(String status);
}
