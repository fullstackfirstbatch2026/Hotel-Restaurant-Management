package com.hotel.restaurant.repository;

import com.hotel.restaurant.model.RestaurantOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<RestaurantOrder, Long> {

    List<RestaurantOrder> findAllByOrderByOrderDateDesc();
    List<RestaurantOrder> findByOrderStatusOrderByOrderDateDesc(String orderStatus);
    long countByOrderStatus(String orderStatus);

    @Query(value = "SELECT COALESCE(SUM(total_amount), 0) FROM RESTAURANT_ORDERS", nativeQuery = true)
    BigDecimal calculateTotalRevenue();

    /**
     * Requirement: Display orders with guest and menu details using a JOIN.
     * Joins RESTAURANT_ORDERS, GUESTS (LEFT JOIN for walk-ins), ORDER_ITEMS, and MENU_ITEMS.
     */
    @Query(value = """
        SELECT 
            ro.order_id,
            ro.order_date,
            ro.order_type,
            ro.table_number,
            ro.order_status,
            g.guest_id,
            CASE WHEN g.guest_id IS NOT NULL THEN CONCAT(g.first_name, ' ', g.last_name) ELSE 'Walk-in Guest' END AS guest_name,
            COALESCE(g.room_number, 'N/A') AS room_number,
            mi.item_id,
            mi.item_name,
            mi.category,
            mi.dietary_type,
            oi.quantity,
            oi.unit_price,
            oi.subtotal,
            ro.total_amount
        FROM RESTAURANT_ORDERS ro
        LEFT JOIN GUESTS g ON ro.guest_id = g.guest_id
        JOIN ORDER_ITEMS oi ON ro.order_id = oi.order_id
        JOIN MENU_ITEMS mi ON oi.item_id = mi.item_id
        ORDER BY ro.order_date DESC, ro.order_id DESC, oi.order_item_id ASC
        """, nativeQuery = true)
    List<Object[]> findOrdersWithGuestAndMenuDetailsRaw();

    /**
     * Requirement: Stored Function execution - CALCULATE_ORDER_BILL(order_id)
     */
    @Query(value = "SELECT CALCULATE_ORDER_BILL(:orderId) FROM (VALUES(1))", nativeQuery = true)
    BigDecimal callCalculateOrderBillFunction(@Param("orderId") Long orderId);
}
