package com.hotel.restaurant.service;

import com.hotel.restaurant.model.Guest;
import com.hotel.restaurant.repository.GuestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class GuestService {

    private final GuestRepository guestRepository;

    @Autowired
    public GuestService(GuestRepository guestRepository) {
        this.guestRepository = guestRepository;
    }

    public List<Guest> getAllGuests() {
        return guestRepository.findAll();
    }

    public List<Guest> getActiveGuests() {
        return guestRepository.findByStatus("CHECKED_IN");
    }

    public Optional<Guest> getGuestById(Long id) {
        return guestRepository.findById(id);
    }

    public Guest saveGuest(Guest guest) {
        if (guest.getCheckInDate() == null) {
            guest.setCheckInDate(LocalDate.now());
        }
        if (guest.getStatus() == null) {
            guest.setStatus("CHECKED_IN");
        }
        return guestRepository.save(guest);
    }

    public Optional<Guest> checkOutGuest(Long id) {
        return guestRepository.findById(id).map(guest -> {
            guest.setStatus("CHECKED_OUT");
            guest.setCheckOutDate(LocalDate.now());
            return guestRepository.save(guest);
        });
    }
}
