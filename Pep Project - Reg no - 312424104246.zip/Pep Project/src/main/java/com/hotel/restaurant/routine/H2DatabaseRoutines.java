package com.hotel.restaurant.routine;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.*;

/**
 * Database Routines exposed as H2 Stored Procedures and Stored Functions.
 * In H2 Database, the first java.sql.Connection parameter is automatically supplied by H2.
 */
public class H2DatabaseRoutines {

    /**
     * Stored Function: CALCULATE_ORDER_BILL(order_id)
     * Called in SQL as: SELECT CALCULATE_ORDER_BILL(1)
     */
    public static BigDecimal calculateOrderBill(Connection conn, Long orderId) throws SQLException {
        if (orderId == null) {
            return BigDecimal.ZERO;
        }

        String sql = "SELECT ro.total_amount, g.status AS guest_status " +
                     "FROM RESTAURANT_ORDERS ro " +
                     "LEFT JOIN GUESTS g ON ro.guest_id = g.guest_id " +
                     "WHERE ro.order_id = ?";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setLong(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return BigDecimal.ZERO;
                }
                BigDecimal subtotal = rs.getBigDecimal("total_amount");
                if (subtotal == null) {
                    subtotal = BigDecimal.ZERO;
                }
                String guestStatus = rs.getString("guest_status");

                // 5% Tax (GST)
                BigDecimal tax = subtotal.multiply(new BigDecimal("0.05"));
                // 5% Service Charge
                BigDecimal serviceCharge = subtotal.multiply(new BigDecimal("0.05"));
                // 10% Hotel Guest Discount if active guest
                BigDecimal discount = BigDecimal.ZERO;
                if ("CHECKED_IN".equalsIgnoreCase(guestStatus)) {
                    discount = subtotal.multiply(new BigDecimal("0.10"));
                }

                BigDecimal total = subtotal.add(tax).add(serviceCharge).subtract(discount);
                return total.setScale(2, RoundingMode.HALF_UP);
            }
        }
    }

    /**
     * Stored Procedure: CREATE_RESTAURANT_ORDER
     * Called in SQL as: CALL CREATE_RESTAURANT_ORDER(guestId, orderType, tableNumber, notes, itemsData)
     */
    public static Long createRestaurantOrder(Connection conn, Long guestId, String orderType,
                                             String tableNumber, String notes, String itemsData) throws SQLException {
        if (orderType == null || orderType.trim().isEmpty()) {
            orderType = "DINE_IN";
        }

        // 1. Insert header into RESTAURANT_ORDERS
        String insertOrderSql = "INSERT INTO RESTAURANT_ORDERS (guest_id, order_date, order_type, table_number, order_status, total_amount, notes) " +
                                "VALUES (?, CURRENT_TIMESTAMP, ?, ?, 'PENDING', 0.00, ?)";

        long newOrderId;
        try (PreparedStatement psOrder = conn.prepareStatement(insertOrderSql, Statement.RETURN_GENERATED_KEYS)) {
            if (guestId != null && guestId > 0) {
                psOrder.setLong(1, guestId);
            } else {
                psOrder.setNull(1, Types.BIGINT);
            }
            psOrder.setString(2, orderType);
            psOrder.setString(3, tableNumber != null ? tableNumber : "N/A");
            psOrder.setString(4, notes != null ? notes : "");
            psOrder.executeUpdate();

            try (ResultSet keys = psOrder.getGeneratedKeys()) {
                if (keys.next()) {
                    newOrderId = keys.getLong(1);
                } else {
                    try (Statement st = conn.createStatement();
                         ResultSet rs = st.executeQuery("SELECT SCOPE_IDENTITY()")) {
                        if (rs.next()) {
                            newOrderId = rs.getLong(1);
                        } else {
                            throw new SQLException("Failed to retrieve generated order_id.");
                        }
                    }
                }
            }
        }

        // 2. Parse and Insert ORDER_ITEMS
        BigDecimal orderTotal = BigDecimal.ZERO;
        if (itemsData != null && !itemsData.trim().isEmpty()) {
            String[] pairs = itemsData.split(",");
            String findItemSql = "SELECT price FROM MENU_ITEMS WHERE item_id = ?";
            String insertItemSql = "INSERT INTO ORDER_ITEMS (order_id, item_id, quantity, unit_price, subtotal) VALUES (?, ?, ?, ?, ?)";

            for (String pair : pairs) {
                String[] parts = pair.trim().split(":");
                if (parts.length == 2) {
                    try {
                        long itemId = Long.parseLong(parts[0].trim());
                        int qty = Integer.parseInt(parts[1].trim());

                        if (qty <= 0) continue;

                        BigDecimal unitPrice = BigDecimal.ZERO;
                        try (PreparedStatement psItem = conn.prepareStatement(findItemSql)) {
                            psItem.setLong(1, itemId);
                            try (ResultSet rs = psItem.executeQuery()) {
                                if (rs.next()) {
                                    unitPrice = rs.getBigDecimal("price");
                                }
                            }
                        }

                        BigDecimal subtotal = unitPrice.multiply(BigDecimal.valueOf(qty));
                        orderTotal = orderTotal.add(subtotal);

                        try (PreparedStatement psInsertItem = conn.prepareStatement(insertItemSql)) {
                            psInsertItem.setLong(1, newOrderId);
                            psInsertItem.setLong(2, itemId);
                            psInsertItem.setInt(3, qty);
                            psInsertItem.setBigDecimal(4, unitPrice);
                            psInsertItem.setBigDecimal(5, subtotal);
                            psInsertItem.executeUpdate();
                        }
                    } catch (NumberFormatException ignored) {
                    }
                }
            }
        }

        // 3. Update total amount on RESTAURANT_ORDERS
        String updateTotalSql = "UPDATE RESTAURANT_ORDERS SET total_amount = ? WHERE order_id = ?";
        try (PreparedStatement psUpdate = conn.prepareStatement(updateTotalSql)) {
            psUpdate.setBigDecimal(1, orderTotal);
            psUpdate.setLong(2, newOrderId);
            psUpdate.executeUpdate();
        }

        return newOrderId;
    }
}
