package com.hotel.restaurant.service;

import com.hotel.restaurant.dto.AboveAverageItemDTO;
import com.hotel.restaurant.model.MenuItem;
import com.hotel.restaurant.repository.MenuItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class MenuService {

    private final MenuItemRepository menuItemRepository;

    @Autowired
    public MenuService(MenuItemRepository menuItemRepository) {
        this.menuItemRepository = menuItemRepository;
    }

    public List<MenuItem> getAllMenuItems() {
        return menuItemRepository.findAll();
    }

    public List<MenuItem> getAvailableMenuItems() {
        return menuItemRepository.findByIsAvailableTrue();
    }

    public Optional<MenuItem> getMenuItemById(Long id) {
        return menuItemRepository.findById(id);
    }

    public MenuItem saveMenuItem(MenuItem item) {
        return menuItemRepository.save(item);
    }

    /**
     * Requirement: Find menu items ordered above average using a subquery.
     */
    public List<AboveAverageItemDTO> getMenuItemsOrderedAboveAverage() {
        List<Object[]> rawList = menuItemRepository.findMenuItemsOrderedAboveAverageRaw();
        List<AboveAverageItemDTO> result = new ArrayList<>();

        for (Object[] row : rawList) {
            Long itemId = row[0] != null ? ((Number) row[0]).longValue() : null;
            String itemName = (String) row[1];
            String category = (String) row[2];
            String dietaryType = (String) row[3];
            BigDecimal price = row[4] != null ? new BigDecimal(row[4].toString()) : BigDecimal.ZERO;
            Long totalQty = row[5] != null ? ((Number) row[5]).longValue() : 0L;
            Long totalOrders = row[6] != null ? ((Number) row[6]).longValue() : 0L;
            Double benchmarkAvg = row[7] != null ? ((Number) row[7]).doubleValue() : 0.0;

            result.add(new AboveAverageItemDTO(itemId, itemName, category, dietaryType, price, totalQty, totalOrders, benchmarkAvg));
        }

        return result;
    }
}
