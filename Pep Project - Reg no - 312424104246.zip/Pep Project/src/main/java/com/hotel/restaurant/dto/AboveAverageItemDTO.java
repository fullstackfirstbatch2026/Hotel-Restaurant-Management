package com.hotel.restaurant.dto;

import java.math.BigDecimal;

public class AboveAverageItemDTO {
    private Long itemId;
    private String itemName;
    private String category;
    private String dietaryType;
    private BigDecimal price;
    private Long totalQuantityOrdered;
    private Long totalOrdersCount;
    private Double benchmarkAverage;

    public AboveAverageItemDTO() {
    }

    public AboveAverageItemDTO(Long itemId, String itemName, String category, String dietaryType,
                               BigDecimal price, Long totalQuantityOrdered, Long totalOrdersCount, Double benchmarkAverage) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.category = category;
        this.dietaryType = dietaryType;
        this.price = price;
        this.totalQuantityOrdered = totalQuantityOrdered;
        this.totalOrdersCount = totalOrdersCount;
        this.benchmarkAverage = benchmarkAverage;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDietaryType() {
        return dietaryType;
    }

    public void setDietaryType(String dietaryType) {
        this.dietaryType = dietaryType;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Long getTotalQuantityOrdered() {
        return totalQuantityOrdered;
    }

    public void setTotalQuantityOrdered(Long totalQuantityOrdered) {
        this.totalQuantityOrdered = totalQuantityOrdered;
    }

    public Long getTotalOrdersCount() {
        return totalOrdersCount;
    }

    public void setTotalOrdersCount(Long totalOrdersCount) {
        this.totalOrdersCount = totalOrdersCount;
    }

    public Double getBenchmarkAverage() {
        return benchmarkAverage;
    }

    public void setBenchmarkAverage(Double benchmarkAverage) {
        this.benchmarkAverage = benchmarkAverage;
    }
}
