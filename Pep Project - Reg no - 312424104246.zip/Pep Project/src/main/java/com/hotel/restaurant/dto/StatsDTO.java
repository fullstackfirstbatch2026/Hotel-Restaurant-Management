package com.hotel.restaurant.dto;

import java.math.BigDecimal;

public class StatsDTO {
    private long totalGuests;
    private long activeGuests;
    private long totalMenuItems;
    private long totalOrders;
    private long pendingOrders;
    private BigDecimal totalRevenue;
    private long aboveAverageItemsCount;

    public StatsDTO() {
    }

    public StatsDTO(long totalGuests, long activeGuests, long totalMenuItems, long totalOrders,
                    long pendingOrders, BigDecimal totalRevenue, long aboveAverageItemsCount) {
        this.totalGuests = totalGuests;
        this.activeGuests = activeGuests;
        this.totalMenuItems = totalMenuItems;
        this.totalOrders = totalOrders;
        this.pendingOrders = pendingOrders;
        this.totalRevenue = totalRevenue;
        this.aboveAverageItemsCount = aboveAverageItemsCount;
    }

    public long getTotalGuests() {
        return totalGuests;
    }

    public void setTotalGuests(long totalGuests) {
        this.totalGuests = totalGuests;
    }

    public long getActiveGuests() {
        return activeGuests;
    }

    public void setActiveGuests(long activeGuests) {
        this.activeGuests = activeGuests;
    }

    public long getTotalMenuItems() {
        return totalMenuItems;
    }

    public void setTotalMenuItems(long totalMenuItems) {
        this.totalMenuItems = totalMenuItems;
    }

    public long getTotalOrders() {
        return totalOrders;
    }

    public void setTotalOrders(long totalOrders) {
        this.totalOrders = totalOrders;
    }

    public long getPendingOrders() {
        return pendingOrders;
    }

    public void setPendingOrders(long pendingOrders) {
        this.pendingOrders = pendingOrders;
    }

    public BigDecimal getTotalRevenue() {
        return totalRevenue;
    }

    public void setTotalRevenue(BigDecimal totalRevenue) {
        this.totalRevenue = totalRevenue;
    }

    public long getAboveAverageItemsCount() {
        return aboveAverageItemsCount;
    }

    public void setAboveAverageItemsCount(long aboveAverageItemsCount) {
        this.aboveAverageItemsCount = aboveAverageItemsCount;
    }
}
