package com.hotel.restaurant.dto;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;

public class DetailedOrderDTO {
    private Long orderId;
    private LocalDateTime orderDate;
    private String orderType;
    private String tableNumber;
    private String orderStatus;
    private Long guestId;
    private String guestName;
    private String roomNumber;
    private Long itemId;
    private String itemName;
    private String category;
    private String dietaryType;
    private Integer quantity;
    private BigDecimal unitPrice;
    private BigDecimal subtotal;
    private BigDecimal orderTotal;

    public DetailedOrderDTO() {
    }

    public DetailedOrderDTO(Long orderId, Object orderDate, String orderType, String tableNumber,
                            String orderStatus, Long guestId, String guestName, String roomNumber,
                            Long itemId, String itemName, String category, String dietaryType,
                            Integer quantity, BigDecimal unitPrice, BigDecimal subtotal, BigDecimal orderTotal) {
        this.orderId = orderId;
        if (orderDate instanceof Timestamp) {
            this.orderDate = ((Timestamp) orderDate).toLocalDateTime();
        } else if (orderDate instanceof LocalDateTime) {
            this.orderDate = (LocalDateTime) orderDate;
        }
        this.orderType = orderType;
        this.tableNumber = tableNumber;
        this.orderStatus = orderStatus;
        this.guestId = guestId;
        this.guestName = guestName != null && !guestName.trim().isEmpty() ? guestName : "Walk-in Guest";
        this.roomNumber = roomNumber != null ? roomNumber : "N/A";
        this.itemId = itemId;
        this.itemName = itemName;
        this.category = category;
        this.dietaryType = dietaryType;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
        this.subtotal = subtotal;
        this.orderTotal = orderTotal;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public LocalDateTime getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDateTime orderDate) {
        this.orderDate = orderDate;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getTableNumber() {
        return tableNumber;
    }

    public void setTableNumber(String tableNumber) {
        this.tableNumber = tableNumber;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public Long getGuestId() {
        return guestId;
    }

    public void setGuestId(Long guestId) {
        this.guestId = guestId;
    }

    public String getGuestName() {
        return guestName;
    }

    public void setGuestName(String guestName) {
        this.guestName = guestName;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDietaryType() {
        return dietaryType;
    }

    public void setDietaryType(String dietaryType) {
        this.dietaryType = dietaryType;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }

    public BigDecimal getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(BigDecimal subtotal) {
        this.subtotal = subtotal;
    }

    public BigDecimal getOrderTotal() {
        return orderTotal;
    }

    public void setOrderTotal(BigDecimal orderTotal) {
        this.orderTotal = orderTotal;
    }
}
