package com.hotel.restaurant.controller;

import com.hotel.restaurant.dto.StatsDTO;
import com.hotel.restaurant.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/stats")
@CrossOrigin(origins = "*")
public class StatsController {

    private final OrderService orderService;

    @Autowired
    public StatsController(OrderService orderService) {
        this.orderService = orderService;
    }

    @GetMapping
    public ResponseEntity<StatsDTO> getDashboardStats() {
        return ResponseEntity.ok(orderService.getStats());
    }
}
