package com.hotel.restaurant.service;

import com.hotel.restaurant.dto.*;
import com.hotel.restaurant.model.Guest;
import com.hotel.restaurant.model.OrderAuditLog;
import com.hotel.restaurant.model.RestaurantOrder;
import com.hotel.restaurant.repository.GuestRepository;
import com.hotel.restaurant.repository.MenuItemRepository;
import com.hotel.restaurant.repository.OrderAuditLogRepository;
import com.hotel.restaurant.repository.OrderRepository;
import com.hotel.restaurant.routine.H2DatabaseRoutines;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class OrderService {

    private final OrderRepository orderRepository;
    private final GuestRepository guestRepository;
    private final MenuItemRepository menuItemRepository;
    private final OrderAuditLogRepository auditLogRepository;
    private final JdbcTemplate jdbcTemplate;

    @PersistenceContext
    private EntityManager entityManager;

    @Autowired
    public OrderService(OrderRepository orderRepository,
                        GuestRepository guestRepository,
                        MenuItemRepository menuItemRepository,
                        OrderAuditLogRepository auditLogRepository,
                        JdbcTemplate jdbcTemplate) {
        this.orderRepository = orderRepository;
        this.guestRepository = guestRepository;
        this.menuItemRepository = menuItemRepository;
        this.auditLogRepository = auditLogRepository;
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<RestaurantOrder> getAllOrders() {
        return orderRepository.findAllByOrderByOrderDateDesc();
    }

    public Optional<RestaurantOrder> getOrderById(Long id) {
        return orderRepository.findById(id);
    }

    /**
     * Requirement 1: Display orders with guest and menu details using a JOIN.
     */
    public List<DetailedOrderDTO> getDetailedOrders() {
        List<Object[]> rows = orderRepository.findOrdersWithGuestAndMenuDetailsRaw();
        List<DetailedOrderDTO> results = new ArrayList<>();

        for (Object[] r : rows) {
            Long orderId = r[0] != null ? ((Number) r[0]).longValue() : null;
            Object orderDate = r[1];
            String orderType = (String) r[2];
            String tableNumber = (String) r[3];
            String orderStatus = (String) r[4];
            Long guestId = r[5] != null ? ((Number) r[5]).longValue() : null;
            String guestName = (String) r[6];
            String roomNumber = (String) r[7];
            Long itemId = r[8] != null ? ((Number) r[8]).longValue() : null;
            String itemName = (String) r[9];
            String category = (String) r[10];
            String dietaryType = (String) r[11];
            Integer quantity = r[12] != null ? ((Number) r[12]).intValue() : 0;
            BigDecimal unitPrice = r[13] != null ? new BigDecimal(r[13].toString()) : BigDecimal.ZERO;
            BigDecimal subtotal = r[14] != null ? new BigDecimal(r[14].toString()) : BigDecimal.ZERO;
            BigDecimal orderTotal = r[15] != null ? new BigDecimal(r[15].toString()) : BigDecimal.ZERO;

            results.add(new DetailedOrderDTO(orderId, orderDate, orderType, tableNumber, orderStatus,
                    guestId, guestName, roomNumber, itemId, itemName, category, dietaryType,
                    quantity, unitPrice, subtotal, orderTotal));
        }

        return results;
    }

    /**
     * Requirement 3: Procedure: Create restaurant order.
     * Executes the Database Stored Procedure CREATE_RESTAURANT_ORDER with connection safety.
     */
    public RestaurantOrder createOrderViaProcedure(OrderCreateRequest request) {
        String itemsData = request.toProcedureItemsData();
        String orderType = request.getOrderType() != null ? request.getOrderType() : "DINE_IN";
        String tableNo = request.getTableNumber() != null ? request.getTableNumber() : "Table 1";
        String notes = request.getNotes() != null ? request.getNotes() : "";
        Long guestId = request.getGuestId();

        // Direct execution of the stored procedure routine on the active JDBC connection
        Long createdOrderId = jdbcTemplate.execute((Connection conn) -> {
            try {
                return H2DatabaseRoutines.createRestaurantOrder(conn, guestId, orderType, tableNo, notes, itemsData);
            } catch (SQLException e) {
                throw new RuntimeException("Database Stored Procedure Error: " + e.getMessage(), e);
            }
        });

        if (createdOrderId == null) {
            throw new RuntimeException("Stored procedure did not return an order ID.");
        }

        entityManager.flush();
        entityManager.clear();

        return orderRepository.findById(createdOrderId)
                .orElseThrow(() -> new RuntimeException("Created order could not be retrieved."));
    }

    /**
     * Requirement 4: Function: Calculate order bill.
     * Calls the H2 Stored Function CALCULATE_ORDER_BILL with connection safety.
     */
    public BillCalculationDTO calculateBillViaFunction(Long orderId) {
        RestaurantOrder order = orderRepository.findById(orderId)
                .orElseThrow(() -> new IllegalArgumentException("Order not found with ID: " + orderId));

        BigDecimal finalPayableAmount = jdbcTemplate.execute((Connection conn) -> {
            try {
                return H2DatabaseRoutines.calculateOrderBill(conn, orderId);
            } catch (SQLException e) {
                return BigDecimal.ZERO;
            }
        });

        if (finalPayableAmount == null) {
            finalPayableAmount = BigDecimal.ZERO;
        }

        BigDecimal subtotal = order.getTotalAmount() != null ? order.getTotalAmount() : BigDecimal.ZERO;
        BigDecimal tax = subtotal.multiply(new BigDecimal("0.05")).setScale(2, RoundingMode.HALF_UP);
        BigDecimal serviceCharge = subtotal.multiply(new BigDecimal("0.05")).setScale(2, RoundingMode.HALF_UP);

        Guest guest = order.getGuest();
        String guestName = guest != null ? guest.getFullName() : "Walk-in Guest";
        String roomNumber = guest != null ? guest.getRoomNumber() : "N/A";
        String guestStatus = guest != null ? guest.getStatus() : "NON_RESIDENT";

        BigDecimal discount = BigDecimal.ZERO;
        if (guest != null && "CHECKED_IN".equalsIgnoreCase(guest.getStatus())) {
            discount = subtotal.multiply(new BigDecimal("0.10")).setScale(2, RoundingMode.HALF_UP);
        }

        return new BillCalculationDTO(
                order.getOrderId(),
                order.getOrderType(),
                guestName,
                roomNumber,
                guestStatus,
                subtotal,
                tax,
                serviceCharge,
                discount,
                finalPayableAmount.setScale(2, RoundingMode.HALF_UP)
        );
    }

    /**
     * Requirement 5: Trigger: Update order status.
     * Modifies the order status which activates the database trigger TRG_UPDATE_ORDER_STATUS.
     */
    public RestaurantOrder updateOrderStatus(Long orderId, String newStatus) {
        RestaurantOrder order = orderRepository.findById(orderId)
                .orElseThrow(() -> new IllegalArgumentException("Order not found with ID: " + orderId));

        order.setOrderStatus(newStatus.toUpperCase());
        RestaurantOrder saved = orderRepository.saveAndFlush(order);

        return saved;
    }

    public List<OrderAuditLog> getOrderAuditLogs(Long orderId) {
        if (orderId != null) {
            return auditLogRepository.findByOrderIdOrderByChangedAtDesc(orderId);
        }
        return auditLogRepository.findAllByOrderByChangedAtDesc();
    }

    public StatsDTO getStats() {
        long totalGuests = guestRepository.count();
        long activeGuests = guestRepository.countByStatus("CHECKED_IN");
        long totalMenuItems = menuItemRepository.count();
        long totalOrders = orderRepository.count();
        long pendingOrders = orderRepository.countByOrderStatus("PENDING") + orderRepository.countByOrderStatus("PREPARING");
        BigDecimal totalRevenue = orderRepository.calculateTotalRevenue();
        long aboveAverageCount = menuItemRepository.findMenuItemsOrderedAboveAverageRaw().size();

        return new StatsDTO(totalGuests, activeGuests, totalMenuItems, totalOrders, pendingOrders,
                totalRevenue != null ? totalRevenue : BigDecimal.ZERO, aboveAverageCount);
    }
}
