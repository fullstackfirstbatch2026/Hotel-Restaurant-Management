package com.hotel.restaurant.dto;

import java.util.ArrayList;
import java.util.List;

public class OrderCreateRequest {
    private Long guestId;
    private String orderType; // ROOM_SERVICE, DINE_IN, TAKEAWAY
    private String tableNumber;
    private String notes;
    private List<OrderItemRequest> items = new ArrayList<>();

    public OrderCreateRequest() {
    }

    public OrderCreateRequest(Long guestId, String orderType, String tableNumber, String notes, List<OrderItemRequest> items) {
        this.guestId = guestId;
        this.orderType = orderType;
        this.tableNumber = tableNumber;
        this.notes = notes;
        this.items = items;
    }

    public Long getGuestId() {
        return guestId;
    }

    public void setGuestId(Long guestId) {
        this.guestId = guestId;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getTableNumber() {
        return tableNumber;
    }

    public void setTableNumber(String tableNumber) {
        this.tableNumber = tableNumber;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public List<OrderItemRequest> getItems() {
        return items;
    }

    public void setItems(List<OrderItemRequest> items) {
        this.items = items;
    }

    /**
     * Formats items into delimited format "itemId:qty,itemId:qty" for Stored Procedure execution.
     */
    public String toProcedureItemsData() {
        if (items == null || items.isEmpty()) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < items.size(); i++) {
            OrderItemRequest item = items.get(i);
            if (item.getItemId() != null && item.getQuantity() != null && item.getQuantity() > 0) {
                if (sb.length() > 0) sb.append(",");
                sb.append(item.getItemId()).append(":").append(item.getQuantity());
            }
        }
        return sb.toString();
    }
}
