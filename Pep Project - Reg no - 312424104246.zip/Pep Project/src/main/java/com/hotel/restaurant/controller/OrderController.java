package com.hotel.restaurant.controller;

import com.hotel.restaurant.dto.*;
import com.hotel.restaurant.model.OrderAuditLog;
import com.hotel.restaurant.model.RestaurantOrder;
import com.hotel.restaurant.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins = "*")
public class OrderController {

    private final OrderService orderService;

    @Autowired
    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @GetMapping
    public ResponseEntity<List<RestaurantOrder>> getAllOrders() {
        return ResponseEntity.ok(orderService.getAllOrders());
    }

    @GetMapping("/{id}")
    public ResponseEntity<RestaurantOrder> getOrderById(@PathVariable Long id) {
        return orderService.getOrderById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Requirement: Display orders with guest and menu details using a JOIN.
     */
    @GetMapping("/detailed")
    public ResponseEntity<List<DetailedOrderDTO>> getDetailedOrders() {
        List<DetailedOrderDTO> detailedOrders = orderService.getDetailedOrders();
        return ResponseEntity.ok(detailedOrders);
    }

    /**
     * Requirement: Procedure: Create restaurant order.
     */
    @PostMapping("/procedure/create")
    public ResponseEntity<RestaurantOrder> createOrderViaProcedure(@RequestBody OrderCreateRequest request) {
        RestaurantOrder created = orderService.createOrderViaProcedure(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    /**
     * Requirement: Function: Calculate order bill.
     */
    @GetMapping("/{id}/calculate-bill")
    public ResponseEntity<BillCalculationDTO> calculateOrderBill(@PathVariable Long id) {
        BillCalculationDTO bill = orderService.calculateBillViaFunction(id);
        return ResponseEntity.ok(bill);
    }

    /**
     * Requirement: Trigger: Update order status.
     */
    @PatchMapping("/{id}/status")
    public ResponseEntity<RestaurantOrder> updateOrderStatus(@PathVariable Long id,
                                                             @RequestBody StatusUpdateRequest request) {
        RestaurantOrder updated = orderService.updateOrderStatus(id, request.getStatus());
        return ResponseEntity.ok(updated);
    }

    @GetMapping("/{id}/audit-logs")
    public ResponseEntity<List<OrderAuditLog>> getAuditLogsByOrder(@PathVariable Long id) {
        return ResponseEntity.ok(orderService.getOrderAuditLogs(id));
    }

    @GetMapping("/audit-logs")
    public ResponseEntity<List<OrderAuditLog>> getAllAuditLogs() {
        return ResponseEntity.ok(orderService.getOrderAuditLogs(null));
    }
}
