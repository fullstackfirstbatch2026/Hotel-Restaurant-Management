package com.hotel.restaurant.repository;

import com.hotel.restaurant.model.MenuItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MenuItemRepository extends JpaRepository<MenuItem, Long> {
    List<MenuItem> findByCategory(String category);
    List<MenuItem> findByDietaryType(String dietaryType);
    List<MenuItem> findByIsAvailableTrue();

    /**
     * Requirement: Find menu items ordered above average using a subquery.
     * The subquery calculates the average total quantity ordered across all menu items,
     * and the outer query filters menu items whose sum of ordered quantities exceeds that average.
     */
    @Query(value = """
        SELECT 
            mi.item_id AS itemId,
            mi.item_name AS itemName,
            mi.category AS category,
            mi.dietary_type AS dietaryType,
            mi.price AS price,
            SUM(oi.quantity) AS totalQuantityOrdered,
            COUNT(DISTINCT oi.order_id) AS totalOrdersCount,
            (
                SELECT AVG(item_total_qty) 
                FROM (
                    SELECT SUM(quantity) AS item_total_qty 
                    FROM ORDER_ITEMS 
                    GROUP BY item_id
                ) AS sub_counts
            ) AS benchmarkAverage
        FROM MENU_ITEMS mi
        JOIN ORDER_ITEMS oi ON mi.item_id = oi.item_id
        GROUP BY mi.item_id, mi.item_name, mi.category, mi.dietary_type, mi.price
        HAVING SUM(oi.quantity) > (
            SELECT AVG(item_total_qty)
            FROM (
                SELECT SUM(quantity) AS item_total_qty
                FROM ORDER_ITEMS
                GROUP BY item_id
            ) AS avg_counts
        )
        ORDER BY totalQuantityOrdered DESC
        """, nativeQuery = true)
    List<Object[]> findMenuItemsOrderedAboveAverageRaw();
}
