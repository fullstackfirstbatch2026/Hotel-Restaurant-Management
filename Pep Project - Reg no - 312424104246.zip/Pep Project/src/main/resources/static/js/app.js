// Grand Azure Hotel & Fine Dining - Client Controller

let allMenuItems = [];
let allGuests = [];

document.addEventListener('DOMContentLoaded', () => {
  initUserSession();
  loadDashboardData();
});

function initUserSession() {
  const userJson = sessionStorage.getItem('hotelUser');
  if (userJson) {
    try {
      const user = JSON.parse(userJson);
      document.getElementById('navRolePill').textContent = user.role || 'Manager';
      document.getElementById('navUserEmail').textContent = user.email || 'admin@azurehotel.com';
    } catch (e) {
      console.error(e);
    }
  }
}

function logout() {
  sessionStorage.removeItem('hotelUser');
  window.location.href = '/login.html';
}

function switchTab(tabName) {
  document.querySelectorAll('.tab-pane').forEach(el => el.style.display = 'none');
  document.querySelectorAll('.nav-tab').forEach(el => el.classList.remove('active'));

  const activePane = document.getElementById(`tab-${tabName}`);
  if (activePane) {
    activePane.style.display = 'block';
  }

  const tabs = document.querySelectorAll('.nav-tab');
  tabs.forEach(btn => {
    if (btn.getAttribute('onclick')?.includes(tabName)) {
      btn.classList.add('active');
    }
  });

  if (tabName === 'analytics') loadAboveAverageItems();
  if (tabName === 'orders') loadDetailedOrders();
  if (tabName === 'menu') loadMenuCatalog();
  if (tabName === 'guests') loadGuests();
  if (tabName === 'audit') loadAuditLogs();
}

// ----------------------------------------------------
// Dashboard Metrics
// ----------------------------------------------------
async function loadDashboardData() {
  try {
    const res = await fetch('/api/stats');
    if (res.ok) {
      const stats = await res.json();
      document.getElementById('statRevenue').textContent = `$${Number(stats.totalRevenue || 0).toFixed(2)}`;
      document.getElementById('statGuests').textContent = stats.activeGuests;
      document.getElementById('statOrders').textContent = stats.totalOrders;
      document.getElementById('statAboveAvg').textContent = stats.aboveAverageItemsCount;
    }
  } catch (err) {
    console.error('Failed to load stats:', err);
  }

  loadAboveAverageItems();
  loadMenuCatalog();
  loadGuests();
}

// ----------------------------------------------------
// Top Selling Dishes (Subquery Under the Hood)
// ----------------------------------------------------
async function loadAboveAverageItems() {
  const tbody = document.getElementById('aboveAverageTableBody');
  tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; color: var(--text-muted); padding: 2rem;">Loading chef's top delicacies...</td></tr>`;

  try {
    const res = await fetch('/api/menu/above-average');
    const items = await res.json();

    if (!items || items.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; color: var(--text-muted); padding: 2rem;">No dishes currently exceed the average sales threshold.</td></tr>`;
      return;
    }

    tbody.innerHTML = items.map(item => {
      const dietaryClass = item.dietaryType === 'VEG' ? 'dietary-veg' : (item.dietaryType === 'NON_VEG' ? 'dietary-nonveg' : 'dietary-vegan');
      const benchmark = item.benchmarkAverage ? Number(item.benchmarkAverage).toFixed(2) : '0.00';

      return `
        <tr>
          <td><strong style="font-family: var(--font-serif); font-size: 1.15rem; color: #fff;">${escapeHtml(item.itemName)}</strong></td>
          <td><span style="font-size: 0.8rem; font-weight: 700; text-transform: uppercase; color: var(--gold-primary);">${escapeHtml(item.category)}</span></td>
          <td><span class="dietary-badge ${dietaryClass}">${escapeHtml(item.dietaryType)}</span></td>
          <td style="font-family: var(--font-serif); font-size: 1.15rem; font-weight: 700;">$${Number(item.price).toFixed(2)}</td>
          <td><strong style="color: #34d399; font-size: 1.1rem;">${item.totalQuantityOrdered} portions</strong></td>
          <td>${item.totalOrdersCount} orders</td>
          <td style="color: var(--text-muted); font-size: 0.85rem;">Average: ${benchmark} portions</td>
          <td><span class="status-pill status-delivered">★ Chef's Special</span></td>
        </tr>
      `;
    }).join('');
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; color: var(--rose); padding: 2rem;">Error loading data: ${err.message}</td></tr>`;
  }
}

// ----------------------------------------------------
// Orders Explorer (JOIN Under the Hood)
// ----------------------------------------------------
async function loadDetailedOrders() {
  const tbody = document.getElementById('detailedOrdersTableBody');
  tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; color: var(--text-muted); padding: 2rem;">Loading dining orders...</td></tr>`;

  try {
    const res = await fetch('/api/orders/detailed');
    const rows = await res.json();

    if (!rows || rows.length === 0) {
      tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; color: var(--text-muted); padding: 2rem;">No orders recorded yet.</td></tr>`;
      return;
    }

    const orderGroups = new Map();
    rows.forEach(r => {
      if (!orderGroups.has(r.orderId)) {
        orderGroups.set(r.orderId, {
          orderId: r.orderId,
          orderDate: r.orderDate,
          orderType: r.orderType,
          tableNumber: r.tableNumber,
          orderStatus: r.orderStatus,
          guestName: r.guestName,
          roomNumber: r.roomNumber,
          orderTotal: r.orderTotal,
          items: []
        });
      }
      orderGroups.get(r.orderId).items.push({
        itemName: r.itemName,
        category: r.category,
        dietaryType: r.dietaryType,
        quantity: r.quantity,
        unitPrice: r.unitPrice,
        subtotal: r.subtotal
      });
    });

    tbody.innerHTML = Array.from(orderGroups.values()).map(order => {
      const statusClass = `status-${(order.orderStatus || 'pending').toLowerCase()}`;
      const dateStr = order.orderDate ? new Date(order.orderDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : 'Just now';

      const itemsHtml = order.items.map(item => {
        const dietaryClass = item.dietaryType === 'VEG' ? 'dietary-veg' : (item.dietaryType === 'NON_VEG' ? 'dietary-nonveg' : 'dietary-vegan');
        return `
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 5px; padding-bottom: 4px; border-bottom: 1px dashed rgba(255,255,255,0.08);">
            <div>
              <span style="font-weight: 600; color: #fff;">${escapeHtml(item.itemName)}</span>
              <span class="dietary-badge ${dietaryClass}" style="font-size: 0.62rem; margin-left: 6px;">${escapeHtml(item.dietaryType)}</span>
            </div>
            <div style="font-size: 0.85rem; color: var(--text-muted); margin-left: 12px;">
              ${item.quantity} × $${Number(item.unitPrice).toFixed(2)} = <strong style="color: #34d399;">$${Number(item.subtotal).toFixed(2)}</strong>
            </div>
          </div>
        `;
      }).join('');

      return `
        <tr>
          <td><strong style="font-family: var(--font-serif); font-size: 1.25rem; color: var(--gold-primary);">#${order.orderId}</strong></td>
          <td style="font-size: 0.82rem; color: var(--text-muted);">${dateStr}</td>
          <td>
            <span style="font-size: 0.72rem; font-weight: 800; text-transform: uppercase; color: var(--gold-primary);">${escapeHtml(order.orderType)}</span>
            <div style="font-size: 0.85rem; color: #fff; font-weight: 600; margin-top: 3px;">${escapeHtml(order.tableNumber || order.roomNumber || 'N/A')}</div>
          </td>
          <td>
            <strong style="color: #fff; font-size: 0.96rem;">${escapeHtml(order.guestName)}</strong>
            ${order.roomNumber && order.roomNumber !== 'N/A' ? `<div style="font-size: 0.78rem; color: var(--gold-primary); font-weight: 600;">${escapeHtml(order.roomNumber)}</div>` : ''}
          </td>
          <td style="min-width: 290px;">
            ${itemsHtml}
          </td>
          <td style="text-align: center;">
            <span style="font-weight: 700; font-size: 0.88rem; color: var(--text-muted);">${order.items.reduce((sum, it) => sum + it.quantity, 0)} items</span>
          </td>
          <td>
            <strong style="font-family: var(--font-serif); color: #34d399; font-size: 1.3rem;">$${Number(order.orderTotal).toFixed(2)}</strong>
          </td>
          <td><span class="status-pill ${statusClass}">${escapeHtml(order.orderStatus)}</span></td>
          <td>
            <div style="display: flex; gap: 0.45rem;">
              <button class="btn-secondary-sm" onclick="showBillFunction(${order.orderId})" title="Calculate Bill">
                🧾 Bill
              </button>
              <button class="btn-secondary-sm" onclick="openStatusModal(${order.orderId}, '${order.orderStatus}')" title="Update Service Status">
                ⚡ Status
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="9" style="text-align:center; color: var(--rose); padding: 2rem;">Error loading orders: ${err.message}</td></tr>`;
  }
}

// ----------------------------------------------------
// Order Creation (Stored Procedure Under the Hood)
// ----------------------------------------------------
async function handleCreateOrderProcedure(e) {
  e.preventDefault();

  const orderType = document.getElementById('orderTypeSelect').value;
  const guestIdVal = document.getElementById('orderGuestSelect').value;
  const tableNumber = document.getElementById('orderTableNumber').value;
  const notes = document.getElementById('orderNotes').value;

  const items = [];
  document.querySelectorAll('.order-qty-input').forEach(input => {
    const qty = parseInt(input.value, 10);
    if (qty > 0) {
      items.push({
        itemId: parseInt(input.dataset.itemId, 10),
        quantity: qty
      });
    }
  });

  if (items.length === 0) {
    showToast('Please select at least 1 dish portion to order.', 'warning');
    return;
  }

  const payload = {
    guestId: guestIdVal && guestIdVal.trim() !== '' ? parseInt(guestIdVal, 10) : null,
    orderType: orderType,
    tableNumber: tableNumber,
    notes: notes,
    items: items
  };

  const submitBtn = document.getElementById('btnSubmitProcedure');
  submitBtn.disabled = true;
  submitBtn.innerHTML = '<span>Processing Order...</span>';

  try {
    const res = await fetch('/api/orders/procedure/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (res.ok) {
      const createdOrder = await res.json();
      showToast(`Order #${createdOrder.orderId} placed successfully! Total: $${Number(createdOrder.totalAmount).toFixed(2)}`, 'success');
      closeModal('createOrderModal');
      loadDashboardData();
      loadDetailedOrders();
      loadAuditLogs();
    } else {
      const errJson = await res.json().catch(() => null);
      const errMsg = (errJson && errJson.message) ? errJson.message : 'Server encountered an error';
      showToast(`Error: ${errMsg}`, 'error');
    }
  } catch (err) {
    showToast(`Network Error: ${err.message}`, 'error');
  } finally {
    submitBtn.disabled = false;
    submitBtn.innerHTML = '<span>🚀 Place Dining Order</span>';
  }
}

// ----------------------------------------------------
// Guest Check Receipt (Stored Function Under the Hood)
// ----------------------------------------------------
async function showBillFunction(orderId) {
  const container = document.getElementById('billInvoiceContent');
  container.innerHTML = `<div style="text-align:center; padding: 2rem; color: var(--gold-primary);">Calculating Dining Check #${orderId}...</div>`;
  openModal('calculateBillModal');

  try {
    const res = await fetch(`/api/orders/${orderId}/calculate-bill`);
    if (!res.ok) throw new Error('Could not calculate bill.');
    const bill = await res.json();

    const isResident = bill.guestStatus === 'CHECKED_IN';

    container.innerHTML = `
      <div class="guest-receipt">
        <div class="receipt-header">
          <h3>GRAND AZURE</h3>
          <div style="font-size: 0.78rem; letter-spacing: 0.15em; text-transform: uppercase; color: #555; margin-top: 3px;">Hotel & Fine Dining</div>
          <div style="font-size: 0.75rem; color: #777; margin-top: 5px;">Order #${bill.orderId} • ${new Date().toLocaleDateString()}</div>
        </div>

        <div style="font-size: 0.85rem; margin-bottom: 1rem; border-bottom: 1px solid #ddd; padding-bottom: 0.75rem;">
          <div style="display:flex; justify-content:space-between;">
            <span>Guest: <strong>${escapeHtml(bill.guestName)}</strong></span>
            <span>Service: <strong>${escapeHtml(bill.orderType)}</strong></span>
          </div>
          <div style="display:flex; justify-content:space-between; margin-top: 4px;">
            <span>Room/Table: <strong>${escapeHtml(bill.roomNumber)}</strong></span>
            <span>In-House Resident: <strong style="color:${isResident ? '#059669' : '#555'}">${isResident ? 'YES (10% Privilege)' : 'NO'}</strong></span>
          </div>
        </div>

        <div class="receipt-row">
          <span>Food & Beverage Subtotal</span>
          <strong>$${Number(bill.subtotal).toFixed(2)}</strong>
        </div>

        <div class="receipt-row">
          <span>State Dining Tax (5%)</span>
          <span>+$${Number(bill.taxAmount).toFixed(2)}</span>
        </div>

        <div class="receipt-row">
          <span>Hospitality Service Charge (5%)</span>
          <span>+$${Number(bill.serviceChargeAmount).toFixed(2)}</span>
        </div>

        ${Number(bill.discountAmount) > 0 ? `
        <div class="receipt-row" style="color: #059669; font-weight: 700;">
          <span>Resident Privilege Discount (-10%)</span>
          <span>-$${Number(bill.discountAmount).toFixed(2)}</span>
        </div>` : ''}

        <div class="receipt-total">
          <span>FINAL PAYABLE:</span>
          <span style="color: #059669;">$${Number(bill.finalPayableAmount).toFixed(2)}</span>
        </div>

        <div style="text-align: center; margin-top: 1.25rem; font-size: 0.75rem; color: #777;">
          <em>Thank you for dining with us at Grand Azure!</em>
        </div>
      </div>
    `;
  } catch (err) {
    container.innerHTML = `<div style="color: var(--rose); text-align:center; padding: 1.5rem;">Error calculating bill: ${err.message}</div>`;
  }
}

// ----------------------------------------------------
// Order Status Updates (Trigger Under the Hood)
// ----------------------------------------------------
function openStatusModal(orderId, currentStatus) {
  document.getElementById('statusModalOrderId').value = orderId;
  document.getElementById('statusModalOrderTitle').textContent = `Order #${orderId}`;
  document.getElementById('statusModalCurrentStatus').textContent = `Current Status: ${currentStatus || 'PENDING'}`;
  document.getElementById('statusSelect').value = currentStatus ? currentStatus.toUpperCase() : 'PENDING';
  openModal('updateStatusModal');
}

async function handleStatusUpdateSubmit(e) {
  e.preventDefault();
  const orderId = document.getElementById('statusModalOrderId').value;
  const newStatus = document.getElementById('statusSelect').value;

  const btn = document.getElementById('btnUpdateStatus');
  btn.disabled = true;
  btn.innerHTML = '<span>Updating Status...</span>';

  try {
    const res = await fetch(`/api/orders/${orderId}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus })
    });

    if (res.ok) {
      showToast(`Order #${orderId} status updated to ${newStatus}.`, 'success');
      closeModal('updateStatusModal');
      loadDetailedOrders();
      loadDashboardData();
      loadAuditLogs();
    } else {
      const err = await res.text();
      showToast(`Status update failed: ${err}`, 'error');
    }
  } catch (err) {
    showToast(`Network Error: ${err.message}`, 'error');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '<span>⚡ Apply Status Update</span>';
  }
}

// ----------------------------------------------------
// Service Activity Log (Trigger Audit Under the Hood)
// ----------------------------------------------------
async function loadAuditLogs() {
  const tbody = document.getElementById('auditTableBody');
  tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color: var(--text-muted); padding: 2rem;">Loading activity log...</td></tr>`;

  try {
    const res = await fetch('/api/orders/audit-logs');
    const logs = await res.json();

    if (!logs || logs.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color: var(--text-muted); padding: 2rem;">No service activities recorded yet.</td></tr>`;
      return;
    }

    tbody.innerHTML = logs.map(l => {
      const timeStr = l.changedAt ? new Date(l.changedAt).toLocaleString() : 'Just now';
      return `
        <tr>
          <td><strong style="color: var(--gold-primary);">#${l.logId}</strong></td>
          <td><strong style="color: #fff;">Order #${l.orderId}</strong></td>
          <td><span class="status-pill status-${(l.oldStatus || 'pending').toLowerCase()}">${escapeHtml(l.oldStatus || 'INITIAL')}</span></td>
          <td><span class="status-pill status-${(l.newStatus || 'pending').toLowerCase()}">${escapeHtml(l.newStatus)}</span></td>
          <td style="font-size: 0.82rem; color: var(--text-muted);">${timeStr}</td>
          <td style="color: #f8fafc; font-weight: 500;">${escapeHtml(l.actionNote)}</td>
        </tr>
      `;
    }).join('');
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; color: var(--rose); padding: 2rem;">Error loading log: ${err.message}</td></tr>`;
  }
}

// ----------------------------------------------------
// Menu Catalog Tab
// ----------------------------------------------------
const dishIcons = {
  'Appetizer': '🥖',
  'Salad': '🥗',
  'Main Course': '🥩',
  'Dessert': '🍰',
  'Beverage': '🍸'
};

async function loadMenuCatalog() {
  const container = document.getElementById('menuCardsContainer');
  try {
    const res = await fetch('/api/menu');
    allMenuItems = await res.json();

    container.innerHTML = allMenuItems.map(item => {
      const dietaryClass = item.dietaryType === 'VEG' ? 'dietary-veg' : (item.dietaryType === 'NON_VEG' ? 'dietary-nonveg' : 'dietary-vegan');
      const icon = dishIcons[item.category] || '🍽️';

      return `
        <div class="glass-card menu-card">
          <div>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 0.75rem;">
              <span style="font-size: 0.75rem; font-weight: 800; text-transform: uppercase; color: var(--gold-primary); letter-spacing: 0.08em;">${escapeHtml(item.category)}</span>
              <span class="dietary-badge ${dietaryClass}">${escapeHtml(item.dietaryType)}</span>
            </div>
            <div class="dish-icon">${icon}</div>
            <h3 class="dish-title">${escapeHtml(item.itemName)}</h3>
            <p class="dish-desc">${escapeHtml(item.description || '')}</p>
          </div>
          <div style="display:flex; justify-content:space-between; align-items:center; border-top: 1px solid rgba(255,255,255,0.08); padding-top: 1rem;">
            <span class="dish-price">$${Number(item.price).toFixed(2)}</span>
            <button class="btn-secondary-sm" onclick="openCreateOrderModalWithItem(${item.itemId})">
              <span>🛒 Add to Order</span>
            </button>
          </div>
        </div>
      `;
    }).join('');
  } catch (err) {
    container.innerHTML = `<div style="color: var(--rose);">Error loading menu dishes: ${err.message}</div>`;
  }
}

// ----------------------------------------------------
// In-House Residents Directory Tab
// ----------------------------------------------------
async function loadGuests() {
  const tbody = document.getElementById('guestsTableBody');
  try {
    const res = await fetch('/api/guests');
    allGuests = await res.json();

    const select = document.getElementById('orderGuestSelect');
    select.innerHTML = `<option value="">-- Walk-in Customer --</option>` + 
      allGuests.filter(g => g.status === 'CHECKED_IN').map(g => `
        <option value="${g.guestId}">${escapeHtml(g.firstName)} ${escapeHtml(g.lastName)} (${escapeHtml(g.roomNumber)})</option>
      `).join('');

    tbody.innerHTML = allGuests.map(g => {
      const isCheckedIn = g.status === 'CHECKED_IN';
      return `
        <tr>
          <td><strong style="color: var(--gold-primary);">#${g.guestId}</strong></td>
          <td><strong style="color: #fff; font-size: 0.98rem;">${escapeHtml(g.firstName)} ${escapeHtml(g.lastName)}</strong></td>
          <td><span style="font-weight: 700; color: var(--gold-primary);">${escapeHtml(g.roomNumber)}</span></td>
          <td>${escapeHtml(g.phone)}</td>
          <td style="color: var(--text-muted);">${escapeHtml(g.email || 'N/A')}</td>
          <td>${escapeHtml(g.checkInDate)}</td>
          <td>
            <span class="status-pill ${isCheckedIn ? 'status-delivered' : 'status-cancelled'}">
              ${escapeHtml(g.status)}
            </span>
          </td>
          <td>
            ${isCheckedIn ? `
              <button class="btn-secondary-sm" onclick="checkoutGuest(${g.guestId})">
                Check-Out
              </button>
            ` : '<span style="color:var(--text-muted); font-size:0.8rem;">Checked-Out</span>'}
          </td>
        </tr>
      `;
    }).join('');
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; color: var(--rose); padding: 2rem;">Error loading residents: ${err.message}</td></tr>`;
  }
}

async function handleCreateGuest(e) {
  e.preventDefault();
  const payload = {
    firstName: document.getElementById('guestFirstName').value,
    lastName: document.getElementById('guestLastName').value,
    roomNumber: document.getElementById('guestRoomNumber').value,
    phone: document.getElementById('guestPhone').value,
    email: document.getElementById('guestEmail').value
  };

  try {
    const res = await fetch('/api/guests', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (res.ok) {
      showToast('Resident registered & checked-in successfully!', 'success');
      closeModal('newGuestModal');
      loadGuests();
      loadDashboardData();
    }
  } catch (err) {
    showToast(`Error registering resident: ${err.message}`, 'error');
  }
}

async function checkoutGuest(guestId) {
  try {
    const res = await fetch(`/api/guests/${guestId}/checkout`, { method: 'PATCH' });
    if (res.ok) {
      showToast('Resident check-out completed.', 'success');
      loadGuests();
      loadDashboardData();
    }
  } catch (err) {
    showToast(`Check-out failed: ${err.message}`, 'error');
  }
}

// ----------------------------------------------------
// Order Modal Item Selector
// ----------------------------------------------------
function openCreateOrderModal() {
  populateOrderItemsSelector();
  if (allMenuItems.length > 0) {
    setTimeout(() => {
      const firstInput = document.getElementById(`qtyInput_${allMenuItems[0].itemId}`);
      if (firstInput) firstInput.value = "1";
    }, 50);
  }
  openModal('createOrderModal');
}

function openCreateOrderModalWithItem(preselectedItemId) {
  openCreateOrderModal();
  setTimeout(() => {
    const input = document.getElementById(`qtyInput_${preselectedItemId}`);
    if (input) {
      input.value = Math.max(1, parseInt(input.value || '0') + 1);
    }
  }, 100);
}

function populateOrderItemsSelector() {
  const container = document.getElementById('orderItemsSelectorList');
  container.innerHTML = allMenuItems.map(item => `
    <div style="display:flex; justify-content:space-between; align-items:center; padding: 0.6rem 0; border-bottom: 1px solid rgba(255,255,255,0.08);">
      <div>
        <span style="font-weight: 600; color: #fff;">${escapeHtml(item.itemName)}</span>
        <span style="font-family: var(--font-serif); font-size: 1rem; font-weight: 700; color: var(--gold-primary); margin-left: 0.6rem;">$${Number(item.price).toFixed(2)}</span>
      </div>
      <div>
        <input type="number" min="0" max="99" value="0" 
               id="qtyInput_${item.itemId}"
               data-item-id="${item.itemId}"
               class="order-qty-input form-control" 
               style="width: 70px; padding: 0.35rem 0.5rem; text-align: center;">
      </div>
    </div>
  `).join('');
}

function toggleOrderTypeFields() {
  const type = document.getElementById('orderTypeSelect').value;
  const tableInput = document.getElementById('orderTableNumber');
  if (type === 'ROOM_SERVICE') {
    tableInput.placeholder = 'e.g. Suite 401';
    tableInput.value = 'Suite 401';
  } else if (type === 'DINE_IN') {
    tableInput.placeholder = 'e.g. Table 4';
    tableInput.value = 'Table 4';
  } else {
    tableInput.placeholder = 'e.g. Counter Pickup';
    tableInput.value = 'Takeaway';
  }
}

function openNewGuestModal() {
  openModal('newGuestModal');
}

function openModal(id) {
  document.getElementById(id)?.classList.add('open');
}

function closeModal(id) {
  document.getElementById(id)?.classList.remove('open');
}

function showToast(msg, type = 'info') {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = 'toast';
  const icon = type === 'success' ? '✅' : (type === 'warning' ? '⚠️' : (type === 'error' ? '❌' : 'ℹ️'));
  toast.innerHTML = `<span style="font-size: 1.2rem;">${icon}</span> <span>${escapeHtml(msg)}</span>`;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 4500);
}

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
