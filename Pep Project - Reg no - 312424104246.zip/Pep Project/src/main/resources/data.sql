-- ==========================================================
-- SEED DATA FOR HOTEL RESTAURANT MANAGEMENT SYSTEM
-- ==========================================================

-- 1. Populate GUESTS
INSERT INTO GUESTS (guest_id, first_name, last_name, room_number, phone, email, check_in_date, check_out_date, status) VALUES
(1, 'Alexander', 'Wright', 'Suite 401', '+1-555-0192', 'alex.wright@luxuryhotel.com', CURRENT_DATE - 2, CURRENT_DATE + 3, 'CHECKED_IN'),
(2, 'Sophia', 'Martinez', 'Room 205', '+1-555-0144', 'sophia.m@gmail.com', CURRENT_DATE - 1, CURRENT_DATE + 2, 'CHECKED_IN'),
(3, 'Liam', 'Johnson', 'Room 312', '+1-555-0187', 'liam.j@outlook.com', CURRENT_DATE - 3, CURRENT_DATE + 1, 'CHECKED_IN'),
(4, 'Emma', 'Davis', 'Suite 502', '+1-555-0211', 'emma.davis@corp.org', CURRENT_DATE, CURRENT_DATE + 4, 'CHECKED_IN'),
(5, 'Lucas', 'Brown', 'Room 108', '+1-555-0299', 'lucas.b@yahoo.com', CURRENT_DATE - 4, CURRENT_DATE - 1, 'CHECKED_OUT');

-- 2. Populate MENU_ITEMS
INSERT INTO MENU_ITEMS (item_id, item_name, category, dietary_type, price, description, is_available) VALUES
(1, 'Truffle Mushroom Bruschetta', 'Appetizer', 'VEG', 14.50, 'Toasted sourdough topped with wild forest mushrooms, thyme and white truffle oil', TRUE),
(2, 'Crispy Calamari Fritti', 'Appetizer', 'NON_VEG', 16.00, 'Tender calamari rings with lemon herb aioli and chili flakes', TRUE),
(3, 'Classic Caesar Salad', 'Salad', 'VEG', 12.00, 'Crisp romaine, garlic herb croutons, aged parmesan and house caesar dressing', TRUE),
(4, 'Grilled Prime Ribeye Steak', 'Main Course', 'NON_VEG', 38.50, '300g USDA prime steak with roasted garlic mash and rosemary red wine jus', TRUE),
(5, 'Pan-Seared Atlantic Salmon', 'Main Course', 'NON_VEG', 32.00, 'Crispy skin salmon served over saffron risotto with lemon butter drizzle', TRUE),
(6, 'Wild Forest Mushroom Risotto', 'Main Course', 'VEG', 24.00, 'Creamy arborio rice with porcini mushrooms, parmesan crisp and fresh herbs', TRUE),
(7, 'Handcrafted Margherita Pizza', 'Main Course', 'VEG', 18.00, 'San Marzano tomato sauce, fresh buffalo mozzarella and garden basil', TRUE),
(8, 'Signature Dark Chocolate Fondant', 'Dessert', 'VEG', 11.50, 'Warm molten chocolate cake paired with Madagascan vanilla bean gelato', TRUE),
(9, 'Classic New York Cheesecake', 'Dessert', 'VEG', 10.00, 'Creamy baked cheesecake with wild strawberry coulis', TRUE),
(10, 'Artisan Cappuccino', 'Beverage', 'VEG', 5.50, 'Single-origin espresso with velvety steamed micro-foam milk', TRUE),
(11, 'Tropical Passionfruit Spritz', 'Beverage', 'VEGAN', 8.50, 'Sparkling mocktail with fresh passionfruit, mint, lime and club soda', TRUE),
(12, 'Royal Darjeeling Tea', 'Beverage', 'VEGAN', 4.50, 'Single estate black tea served in an artisan porcelain pot', TRUE);

-- 3. Populate RESTAURANT_ORDERS
INSERT INTO RESTAURANT_ORDERS (order_id, guest_id, order_date, order_type, table_number, order_status, total_amount, notes) VALUES
(1, 1, CURRENT_TIMESTAMP - INTERVAL '4' HOUR, 'ROOM_SERVICE', 'Suite 401', 'DELIVERED', 83.50, 'Extra cutlery requested, deliver to room suite'),
(2, 2, CURRENT_TIMESTAMP - INTERVAL '3' HOUR, 'DINE_IN', 'Table 4', 'BILLED', 56.50, 'Celebrating anniversary'),
(3, 3, CURRENT_TIMESTAMP - INTERVAL '2' HOUR, 'DINE_IN', 'Table 12', 'PREPARING', 76.00, 'Less spicy for risotto'),
(4, 4, CURRENT_TIMESTAMP - INTERVAL '45' MINUTE, 'ROOM_SERVICE', 'Suite 502', 'PENDING', 42.00, 'Ring doorbell twice'),
(5, NULL, CURRENT_TIMESTAMP - INTERVAL '15' MINUTE, 'DINE_IN', 'Table 7', 'PENDING', 30.50, 'Walk-in guest order');

-- 4. Populate ORDER_ITEMS
-- Order 1: Ribeye Steak (1), Truffle Bruschetta (1), Cappuccino (2), Chocolate Fondant (1)
INSERT INTO ORDER_ITEMS (order_item_id, order_id, item_id, quantity, unit_price, subtotal) VALUES
(1, 1, 4, 1, 38.50, 38.50),
(2, 1, 1, 1, 14.50, 14.50),
(3, 1, 10, 2, 5.50, 11.00),
(4, 1, 8, 1, 11.50, 11.50);

-- Order 2: Atlantic Salmon (1), Caesar Salad (1), Tropical Spritz (1)
INSERT INTO ORDER_ITEMS (order_item_id, order_id, item_id, quantity, unit_price, subtotal) VALUES
(5, 2, 5, 1, 32.00, 32.00),
(6, 2, 3, 1, 12.00, 12.00),
(7, 2, 11, 1, 8.50, 8.50);

-- Order 3: Mushroom Risotto (2), Crispy Calamari (1), Dark Chocolate Fondant (1)
INSERT INTO ORDER_ITEMS (order_item_id, order_id, item_id, quantity, unit_price, subtotal) VALUES
(8, 3, 6, 2, 24.00, 48.00),
(9, 3, 2, 1, 16.00, 16.00),
(10, 3, 8, 1, 11.50, 11.50);

-- Order 4: Margherita Pizza (1), Caesar Salad (1), Cappuccino (2)
INSERT INTO ORDER_ITEMS (order_item_id, order_id, item_id, quantity, unit_price, subtotal) VALUES
(11, 4, 7, 1, 18.00, 18.00),
(12, 4, 3, 1, 12.00, 12.00),
(13, 4, 10, 2, 5.50, 11.00);

-- Order 5: Margherita Pizza (1), Passionfruit Spritz (1), Cappuccino (1)
INSERT INTO ORDER_ITEMS (order_item_id, order_id, item_id, quantity, unit_price, subtotal) VALUES
(14, 5, 7, 1, 18.00, 18.00),
(15, 5, 11, 1, 8.50, 8.50),
(16, 5, 10, 1, 5.50, 5.50);

-- 5. Populate Initial Audit Log entries
INSERT INTO ORDER_AUDIT_LOG (log_id, order_id, old_status, new_status, changed_at, action_note) VALUES
(1, 1, 'PREPARING', 'DELIVERED', CURRENT_TIMESTAMP - INTERVAL '3' HOUR, 'Order delivered to Suite 401'),
(2, 2, 'DELIVERED', 'BILLED', CURRENT_TIMESTAMP - INTERVAL '2' HOUR, 'Bill generated and settled via Card');

-- 6. Advance auto-increment sequences past initial seed data to continue cleanly at #6
ALTER TABLE GUESTS ALTER COLUMN guest_id RESTART WITH 6;
ALTER TABLE MENU_ITEMS ALTER COLUMN item_id RESTART WITH 13;
ALTER TABLE RESTAURANT_ORDERS ALTER COLUMN order_id RESTART WITH 6;
ALTER TABLE ORDER_ITEMS ALTER COLUMN order_item_id RESTART WITH 17;
ALTER TABLE ORDER_AUDIT_LOG ALTER COLUMN log_id RESTART WITH 3;
