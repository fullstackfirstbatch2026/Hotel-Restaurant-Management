-- ==========================================================
-- HOTEL RESTAURANT MANAGEMENT DATABASE SCHEMA (H2 / Standard SQL)
-- ==========================================================

-- 1. Drop existing tables and objects if they exist
DROP TRIGGER IF EXISTS TRG_UPDATE_ORDER_STATUS;
DROP ALIAS IF EXISTS CALCULATE_ORDER_BILL;
DROP ALIAS IF EXISTS CREATE_RESTAURANT_ORDER;
DROP TABLE IF EXISTS ORDER_AUDIT_LOG;
DROP TABLE IF EXISTS ORDER_ITEMS;
DROP TABLE IF EXISTS RESTAURANT_ORDERS;
DROP TABLE IF EXISTS MENU_ITEMS;
DROP TABLE IF EXISTS GUESTS;

-- 2. GUESTS Table
CREATE TABLE GUESTS (
    guest_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    room_number VARCHAR(20) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100),
    check_in_date DATE NOT NULL,
    check_out_date DATE,
    status VARCHAR(20) DEFAULT 'CHECKED_IN' -- CHECKED_IN, CHECKED_OUT
);

-- 3. MENU_ITEMS Table
CREATE TABLE MENU_ITEMS (
    item_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    item_name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL, -- Appetizer, Main Course, Dessert, Beverage, Salad
    dietary_type VARCHAR(20) DEFAULT 'VEG', -- VEG, NON_VEG, VEGAN
    price DECIMAL(10, 2) NOT NULL,
    description VARCHAR(255),
    is_available BOOLEAN DEFAULT TRUE
);

-- 4. RESTAURANT_ORDERS Table
CREATE TABLE RESTAURANT_ORDERS (
    order_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    guest_id BIGINT,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    order_type VARCHAR(20) NOT NULL, -- ROOM_SERVICE, DINE_IN, TAKEAWAY
    table_number VARCHAR(20),
    order_status VARCHAR(20) DEFAULT 'PENDING' NOT NULL, -- PENDING, PREPARING, DELIVERED, BILLED, CANCELLED
    total_amount DECIMAL(10, 2) DEFAULT 0.00 NOT NULL,
    notes VARCHAR(255),
    CONSTRAINT fk_orders_guest FOREIGN KEY (guest_id) REFERENCES GUESTS(guest_id) ON DELETE SET NULL
);

-- 5. ORDER_ITEMS Table
CREATE TABLE ORDER_ITEMS (
    order_item_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_id BIGINT NOT NULL,
    item_id BIGINT NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    CONSTRAINT fk_items_order FOREIGN KEY (order_id) REFERENCES RESTAURANT_ORDERS(order_id) ON DELETE CASCADE,
    CONSTRAINT fk_items_menu FOREIGN KEY (item_id) REFERENCES MENU_ITEMS(item_id) ON DELETE RESTRICT
);

-- 6. ORDER_AUDIT_LOG Table (Captured by Trigger)
CREATE TABLE ORDER_AUDIT_LOG (
    log_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    order_id BIGINT NOT NULL,
    old_status VARCHAR(20),
    new_status VARCHAR(20) NOT NULL,
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    action_note VARCHAR(255)
);

-- ==========================================================
-- STORED PROCEDURES, FUNCTIONS & TRIGGERS (H2 Aliases)
-- ==========================================================

-- Function: Calculate order bill (Subtotal + 5% GST + 5% Service Charge - 10% Hotel Guest Discount if applicable)
CREATE ALIAS IF NOT EXISTS CALCULATE_ORDER_BILL FOR "com.hotel.restaurant.routine.H2DatabaseRoutines.calculateOrderBill";

-- Procedure: Create restaurant order with items and auto-computed total
CREATE ALIAS IF NOT EXISTS CREATE_RESTAURANT_ORDER FOR "com.hotel.restaurant.routine.H2DatabaseRoutines.createRestaurantOrder";

-- Trigger: Update order status & log transitions
CREATE TRIGGER IF NOT EXISTS TRG_UPDATE_ORDER_STATUS 
AFTER UPDATE ON RESTAURANT_ORDERS 
FOR EACH ROW 
CALL "com.hotel.restaurant.routine.OrderStatusTrigger";
